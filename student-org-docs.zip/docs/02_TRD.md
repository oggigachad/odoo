# 02 — Technical Requirements Document (TRD)

How the PRD is built. IDs refer to `01_PRD.md`; decisions to `15_DECISIONS.md`.

## 1. Technology
| Concern | Choice | Decision |
|---|---|---|
| Database | PostgreSQL 16 | D-002 |
| API | Python 3.12, FastAPI, Pydantic v2 | D-004 |
| Data access | SQLAlchemy 2.x (async, asyncpg) + Alembic | D-004 |
| Web | Next.js App Router, TypeScript | D-004 |
| Mobile (Phase 2) | Expo / React Native, `react-native-google-mobile-ads` | D-005 |
| Payments | Hosted-checkout gateway (Razorpay proposed) | D-009 |
| Email | Transactional email API (Resend proposed) | D-011 |
| Receipt storage | Private S3-compatible bucket | D-012 |
| Errors / logs | Sentry + structured JSON logs | — |
| CI | GitHub Actions | `11_GITHUB_ACTIONS.md` |

## 2. Non-functional requirements
| Area | Target |
|---|---|
| Check-in latency | p95 < 300 ms server time |
| API latency | p95 < 500 ms for reads, < 1 s for writes |
| Event page | Loads in < 2 s on 4G |
| Availability | 99% monthly (volunteer-run club; no pager) |
| Concurrency | No oversell of seats or stock under parallel requests |
| Backups | Daily automated backups, 14-day retention, restore tested before launch |
| Accessibility | WCAG 2.1 AA for web |
| Browser / OS | Last two versions of Chrome, Safari, Edge; Android 8+, iOS 15+ |
| Currency / locale | INR, English, `Asia/Kolkata` display time (stored UTC) |

## 3. Core business rules (the logic that must be exactly right)

### 3.1 Active membership
A member is **active** on date *d* when a `memberships` row has `payment_id IS NOT NULL` and `valid_from ≤ d ≤ valid_until`. This is the `active_members` view. Boundary dates are inclusive.

### 3.2 Price selection (MEM-5, TIX-2, MER-2)
- Ticket: per holder email. Active member ⇒ `member_price`, `tickets.member_id` set. Otherwise `non_member_price`, `member_id` NULL.
- Merchandise: buyer is always a member. Active ⇒ `member_price`; expired or unpaid ⇒ `price`.
- Price is copied into `tickets.price_paid` / `order_items.unit_price` at purchase time, so later price edits never change history.

### 3.3 Seat limit (TIX-3)
Layered protection:
1. Service locks the `ticket_types` row (`SELECT … FOR UPDATE`), counts tickets, rejects when full.
2. The `enforce_seat_limit` trigger in `schema.sql` is the final backstop; its error is mapped to `SOLD_OUT`.

### 3.4 Reservations (no schema change)
A purchase must hold seats / stock while the buyer pays.
- **Ticket reservation** = a `tickets` row with `payment_id IS NULL AND price_paid > 0`.
- **Order reservation** = an `orders` row with `status = 'placed'` and `payment_id IS NULL`.
- Reservations expire after `RESERVATION_TTL_MINUTES` (default 15).
- **Lazy cleanup:** before every seat or stock check, the same transaction deletes expired ticket reservations for that ticket type, or cancels expired orders for the affected variants and restores stock. A periodic job repeats this, but correctness never depends on the job running.
- A ticket is **valid** when `payment_id IS NOT NULL OR price_paid = 0` (free tickets have no payment row because `payments.amount > 0`).

### 3.5 Stock (MER-4)
```sql
UPDATE product_variants
SET stock_quantity = stock_quantity - :qty
WHERE variant_id = :id AND stock_quantity >= :qty;   -- 0 rows updated => INSUFFICIENT_STOCK
```
On cancel or expiry: `stock_quantity = stock_quantity + qty`, in the same transaction that sets `status = 'cancelled'`.

### 3.6 Check-in (TIX-6)
```sql
UPDATE tickets t
SET checked_in_at = now(), checked_in_by = :officer_id
FROM ticket_types tt
WHERE tt.ticket_type_id = t.ticket_type_id
  AND tt.event_id = :event_id
  AND t.ticket_code = :code
  AND t.checked_in_at IS NULL
  AND (t.payment_id IS NOT NULL OR t.price_paid = 0)
RETURNING t.ticket_id;
```
Zero rows ⇒ a follow-up `SELECT` decides the exact error: `TICKET_NOT_FOUND`, `TICKET_ALREADY_CHECKED_IN`, `TICKET_UNPAID`, or `TICKET_WRONG_EVENT`. Single statement ⇒ two simultaneous scans cannot both succeed.

### 3.7 Payments
1. Server creates the order with the gateway for the exact computed total and stores the reference in the gateway's metadata (target type and IDs).
2. Buyer pays on the gateway's hosted page. No card data touches our servers.
3. Gateway calls `POST /api/v1/webhooks/payment`. We verify the signature, then in one transaction insert a `payments` row and set `payment_id` on the targets (memberships, tickets, or orders; set order `status = 'paid'`).
4. **Idempotency:** the webhook is processed only if targets are still unpaid, and `payments.external_ref` (proposed, `D-020`) is unique. Retries do nothing.
5. **Late payment** (reservation already expired and seats gone): record in logs and alert; refund through the gateway dashboard (runbook in `13_PRODUCTION_CHECKLIST.md`).
6. Cash: officer-only endpoint inserts `payments` with `method = 'cash'` and links targets in one transaction.

### 3.8 Treasurer arithmetic (TRS-1…5)
- Money in = `SUM(payments.amount)` grouped by `category`.
- Money out = `SUM(expenses.amount) WHERE status = 'reimbursed'`.
- Balance = in − out (`club_balance` view).
- Outstanding = memberships with `payment_id IS NULL`, orders `placed`, expenses `approved` and not reimbursed.

### 3.9 Expense workflow
`submitted → approved | rejected`, `approved → reimbursed`. Only the treasurer transitions; never on one's own expense (`SELF_APPROVAL_NOT_ALLOWED`). `reimbursed_at` is set exactly when status becomes `reimbursed`.

### 3.10 Announcements
Insert the row, then queue one email per member address. Post success does not depend on email success; failed sends are retried (3 attempts, exponential backoff) and logged.

## 4. Scheduled jobs
Run as CLI commands (`python -m app.jobs.<name>`) from the host's scheduler. GitHub Actions cron is best-effort and used only as a fallback for the daily job.
| Job | Frequency | Does |
|---|---|---|
| `renewal_reminders` | Daily | Email members from `memberships_due_for_renewal` **where `payment_id IS NOT NULL`** (until `D-021` fixes the view), then set `renewal_reminder_sent_at` |
| `expire_reservations` | Every 5 min | Delete expired unpaid ticket reservations; cancel expired orders and restore stock |

## 5. Configuration (environment variables)
`APP_ENV`, `DATABASE_URL`, `JWT_SECRET`, `SESSION_TTL_MINUTES` (1440), `MAGIC_LINK_TTL_MINUTES` (15), `RESERVATION_TTL_MINUTES` (15), `TICKET_MAX_PER_PURCHASE` (10), `PAYMENT_KEY_ID`, `PAYMENT_KEY_SECRET`, `PAYMENT_WEBHOOK_SECRET`, `EMAIL_API_KEY`, `EMAIL_FROM`, `STORAGE_ENDPOINT`, `STORAGE_BUCKET`, `STORAGE_ACCESS_KEY`, `STORAGE_SECRET_KEY`, `CORS_ORIGINS`, `SENTRY_DSN`, `ADS_ENABLED`.
Web: `NEXT_PUBLIC_API_BASE_URL`. Mobile: `EXPO_PUBLIC_API_BASE_URL`, `EXPO_PUBLIC_ADMOB_*` (see `10_ADMOB.md`).

## 6. Environments
| Env | Purpose | DB | Payments | Ads |
|---|---|---|---|---|
| local | Development, `docker compose` Postgres | local | gateway test mode | test IDs |
| staging | Pre-release checks | separate DB | test mode | test IDs |
| production | Real club | managed Postgres + backups | live | real IDs |

## 7. Repository layout
```
/database        schema.sql (baseline = migration 0001)
/backend         FastAPI app: api/ services/ repositories/ models/ schemas/ core/ jobs/
/web             Next.js app
/mobile          Expo app (Phase 2)
/docs            these documents
/.github         workflows
CHANGELOG.md
```

## 8. Technical risks
| Risk | Mitigation |
|---|---|
| Oversell under load | Row lock + trigger + race test (`12_TESTING.md`) |
| Paid but reservation expired | Lazy + job cleanup, alert, refund runbook |
| Webhook retries or spoofing | Signature check, idempotent processing |
| Email provider outage | Retry with backoff; announcements still visible on site |
| Schema drift between docs and DB | Migrations only; CI applies schema from scratch |
